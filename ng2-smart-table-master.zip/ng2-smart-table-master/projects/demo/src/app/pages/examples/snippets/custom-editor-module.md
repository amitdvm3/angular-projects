@NgModule({
  imports: [
    // ...
  ],
  entryComponents: [CustomEditorComponent, CustomRenderComponent],
  declarations: [
    // ...
    CustomEditorComponent,
    CustomRenderComponent,
  ],
})