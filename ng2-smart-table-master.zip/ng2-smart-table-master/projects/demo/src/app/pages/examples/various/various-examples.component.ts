import { Component, AfterViewInit } from '@angular/core';

@Component({
  selector: 'various-examples',
  templateUrl: './various-examples.component.html',
})
export class VariousExamplesComponent {

}
