import { Component } from '@angular/core';

@Component({
  selector: 'examples',
  styleUrls: ['./examples.component.scss'],
  templateUrl: 'examples.component.html',
})
export class ExamplesComponent {
}
