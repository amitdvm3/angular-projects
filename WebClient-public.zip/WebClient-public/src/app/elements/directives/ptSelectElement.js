/* @ngInject */
const ptSelectElement = () => ({
    replace: true,
    templateUrl: require('../../../templates/elements/ptSelectElement.tpl.html')
});
export default ptSelectElement;
