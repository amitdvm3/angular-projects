/* @ngInject */
function statesElements() {
    return {
        replace: true,
        restrict: 'E',
        templateUrl: require('../../../templates/elements/statesElements.tpl.html')
    };
}
export default statesElements;
