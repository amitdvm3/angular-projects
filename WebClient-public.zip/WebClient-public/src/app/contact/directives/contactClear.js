/* @ngInject */
function contactClear() {
    return {
        replace: true,
        priority: 100,
        templateUrl: require('../../../templates/contact/contactClear.tpl.html')
    };
}
export default contactClear;
