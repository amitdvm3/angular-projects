/* @ngInject */
const composerHeader = () => ({
    replace: true,
    templateUrl: require('../../../templates/directives/composer/composer-header.tpl.html')
});
export default composerHeader;
