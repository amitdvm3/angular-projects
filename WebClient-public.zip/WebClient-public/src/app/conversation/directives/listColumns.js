/* @ngInject */
const listColumns = () => ({
    replace: true,
    templateUrl: require('../../../templates/partials/conversation-list-columns.tpl.html')
});
export default listColumns;
