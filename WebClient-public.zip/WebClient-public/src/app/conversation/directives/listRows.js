/* @ngInject */
const listRows = () => ({
    replace: true,
    templateUrl: require('../../../templates/partials/conversation-list-rows.tpl.html')
});
export default listRows;
