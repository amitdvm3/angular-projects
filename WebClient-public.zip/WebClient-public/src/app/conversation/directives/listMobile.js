/* @ngInject */
const listMobile = () => ({
    replace: true,
    templateUrl: require('../../../templates/partials/conversation-list-mobile.tpl.html')
});
export default listMobile;
