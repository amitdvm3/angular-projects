/* @ngInject */
const domainsMenuStep = () => ({
    replace: true,
    templateUrl: require('../../../templates/domains/domainsMenuStep.tpl.html')
});
export default domainsMenuStep;
