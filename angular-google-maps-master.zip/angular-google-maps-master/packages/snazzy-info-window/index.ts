// public API
export { AgmSnazzyInfoWindowModule } from './snazzy-info-window.module';
export { AgmSnazzyInfoWindow } from './directives/snazzy-info-window';
