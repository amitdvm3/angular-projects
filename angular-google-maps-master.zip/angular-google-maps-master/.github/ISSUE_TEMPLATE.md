**Issue description**


**Steps to reproduce and a minimal demo of the problem**

_Use stackblitz.com or similar -- try this template as a starting point: https://stackblitz.com/edit/angular-google-maps-demo

_What steps should we try in your demo to see the problem?_

**Current behavior**


**Expected/desired behavior**


**angular-google-maps, Angular, & any other relevant dependency versions**


**Other information**
