// NPM packages (without the org name) that we publish
const packages = [
  'core',
  'snazzy-info-window',
  'js-marker-clusterer',
  'drawing'
];

module.exports = packages;
