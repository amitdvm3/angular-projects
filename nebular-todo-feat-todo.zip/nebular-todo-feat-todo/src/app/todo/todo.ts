export interface Todo {
  completed?: boolean;
  deleted?: boolean;
  inEdit?: boolean;
  message?: string;
}
