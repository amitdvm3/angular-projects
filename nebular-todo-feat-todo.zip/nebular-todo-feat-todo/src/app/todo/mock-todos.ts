export const todos = [
  {
    message: 'Create Nebular TODO demo application',
    completed: true,
  },
  {
    message: 'Deploy to GitHub',
    completed: true,
  },
  {
    message: 'Add Firebase integration example',
    completed: false,
  },
  {
    message: 'Add Dark Theme mode',
    completed: true,
  },
  {
    message: 'Start working on Nebular 5',
    completed: false,
  },
];
