<h1 align="center">Backers and Sponsors</h1>

Work on this calendar is funded entirely by donations. If you'd like to support me and have your name appear here, then please consider [becoming a sponsor](https://github.com/users/mattlewis92/sponsorship)!

- [Become a Backer or Sponsor on GitHub](https://github.com/users/mattlewis92/sponsorship)
- [One-time donation via PayPal](https://www.paypal.me/mattlewis92)

<h2 align="center">Backers and Sponsors</h2>

- [Sylvain Lafaye](https://github.com/sylvain-fr)
- [John Allan Canning](https://github.com/jcanning)
- [Hassan Khan](https://github.com/Khanbhai1990)
- [_Your name here?_](https://github.com/users/mattlewis92/sponsorship)
