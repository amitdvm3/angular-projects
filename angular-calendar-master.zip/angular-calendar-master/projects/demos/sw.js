// Unregister legacy service worker so new docs load
self.registration.unregister();

