export class CState {
  id: string;
  code: string;
  name: string;
}
