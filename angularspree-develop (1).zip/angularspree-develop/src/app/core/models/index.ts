import { Product } from './product';

export { Product };
