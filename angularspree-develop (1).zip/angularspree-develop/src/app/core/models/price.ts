export class Price {
  amount: string;
  currency: string;
}
