export class PaymentKey {
  publishable_key: string;
  key_id: string;
}
