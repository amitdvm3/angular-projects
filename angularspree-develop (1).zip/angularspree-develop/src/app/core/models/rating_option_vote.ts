import { RatingOption } from './rating_option';

export class RatingOptionVote {
  id: string;
  rating_option: RatingOption;
}
