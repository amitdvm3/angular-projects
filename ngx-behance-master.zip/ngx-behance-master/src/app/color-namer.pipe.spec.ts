import { ColorNamerPipe } from './color-namer.pipe';

describe('ColorNamerPipe', () => {
  it('create an instance', () => {
    const pipe = new ColorNamerPipe();
    expect(pipe).toBeTruthy();
  });
});
