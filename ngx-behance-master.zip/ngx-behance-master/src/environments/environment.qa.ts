export const environment = {
  production: false,
  api: 'https://www.behance.net/v2/',
  token: 'tIn2oeG0xiiUVQ5WsUsg9wWHOD1gjFuD',
};
