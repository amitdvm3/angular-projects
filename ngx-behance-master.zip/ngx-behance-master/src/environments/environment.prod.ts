export const environment = {
  production: true,
  api: 'https://www.behance.net/v2/',
  token: 'tIn2oeG0xiiUVQ5WsUsg9wWHOD1gjFuD'
};
